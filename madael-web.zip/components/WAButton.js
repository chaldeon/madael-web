'use client';

import { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';

const WA_NUMBER = '6285121548247';
const WA_MESSAGE =
  'Halo Madael Consult, saya ingin konsultasi mengenai layanan HR Anda.';
const WA_HREF = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(WA_MESSAGE)}`;

export default function WAButton() {
  const { lang } = useLanguage();
  const [hovering, setHovering] = useState(false);

  return (
    <>
      {hovering && (
        <div className="print:hidden fixed bottom-[90px] right-7 bg-white border border-[#E0E0E0] px-3.5 py-2.5 text-xs text-[#3D3D3D] whitespace-nowrap shadow-[0_4px_12px_rgba(0,0,0,0.08)] pointer-events-none z-[998] after:content-[''] after:absolute after:-bottom-1.5 after:right-[22px] after:w-2.5 after:h-2.5 after:bg-white after:border-r after:border-b after:border-[#E0E0E0] after:rotate-45">
          {lang === 'id' ? 'Konsultasi via WhatsApp →' : 'Consult via WhatsApp →'}
        </div>
      )}
      <a
        href={WA_HREF}
        target="_blank"
        rel="noopener noreferrer"
        title="Chat via WhatsApp"
        onMouseEnter={() => setHovering(true)}
        onMouseLeave={() => setHovering(false)}
        className="print:hidden fixed bottom-7 right-7 w-[52px] h-[52px] bg-[#25D366] rounded-full flex items-center justify-center shadow-[0_4px_16px_rgba(37,211,102,0.35)] cursor-pointer z-[998] transition-transform hover:scale-[1.08] hover:shadow-[0_6px_20px_rgba(37,211,102,0.45)]"
      >
        <svg viewBox="0 0 24 24" className="w-[26px] h-[26px] fill-white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
        </svg>
      </a>
    </>
  );
}
